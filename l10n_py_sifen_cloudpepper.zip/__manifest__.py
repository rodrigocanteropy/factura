# -*- coding: utf-8 -*-
{
    "name": "Paraguay - Facturación Electrónica (SIFEN)",
    "version": "18.0.1.0.0",
    "category": "Accounting",
    "summary": "Integración con la SET y SIFEN de Paraguay",
    "author": "Desarrollado a medida",
    "website": "https://www.set.gov.py",
    "license": "LGPL-3",
    "depends": ["account"],
    "data": [
        "security/ir.model.access.csv",
        "data/sifen_document_types.xml",
        "views/invoice_views.xml",
        "views/settings_views.xml",
        "reports/kude_template.xml"
    ],
    "installable": True,
    "application": True,
}
